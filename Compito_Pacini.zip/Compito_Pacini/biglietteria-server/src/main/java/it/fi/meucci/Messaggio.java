package it.fi.meucci;
import java.util.ArrayList;

public class Messaggio {
    ArrayList<Biglietto> B;


    public Messaggio() {
    }

    public Messaggio(ArrayList<Biglietto> B) {
        this.B = B;
    }

    public ArrayList<Biglietto> getB() {
        return this.B;
    }

    public void setB(ArrayList<Biglietto> B) {
        this.B = B;
    }

    public Messaggio B(ArrayList<Biglietto> B) {
        setB(B);
        return this;
    }

}
