package it.fi.meucci;

public class Biglietto {
    public int id;
    public String numero;


    public Biglietto() {
    }

    public Biglietto(int id, String numero) {
        this.id = id;
        this.numero = numero;
    }

    public int getId() {
        return this.id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNumero() {
        return this.numero;
    }

    public void setNumero(String numero) {
        this.numero = numero;
    }

    public Biglietto id(int id) {
        setId(id);
        return this;
    }

    public Biglietto numero(String numero) {
        setNumero(numero);
        return this;
    }

}
  
