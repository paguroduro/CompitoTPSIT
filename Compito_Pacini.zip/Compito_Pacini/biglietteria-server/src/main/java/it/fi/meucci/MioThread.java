package it.fi.meucci;
import java.io.*;
import java.net.*;
import java.util.ArrayList;

public class MioThread extends Thread {
    Socket client;


    public MioThread() {
    }

    public MioThread(Socket client) {
        this.client = client;
    }

    public void run(){
        try{
            Biglietto b1=new Biglietto(1, "palco-2a");
            Biglietto b2=new Biglietto(2, "parterre-3b");
            Biglietto b3=new Biglietto(3, "tribuna-8a");
            Biglietto b4=new Biglietto(4, "palco-2a");
            Biglietto b5=new Biglietto(5, "parterre-3b");
            Biglietto b6=new Biglietto(6, "tribuna-8a");
            ArrayList<Biglietto> lista=new ArrayList<Biglietto>();
            lista.add(b1);
            lista.add(b2);
            lista.add(b3);
            lista.add(b4);
            lista.add(b5);
            lista.add(b6);
            Messaggio l1 = new Messaggio(lista);
            ObjectMapper objectMapper = new ObjectMapper();
            objectMapper.writeValue();
        }catch(Exception e){

        }
    }
 
}
    

    
    

