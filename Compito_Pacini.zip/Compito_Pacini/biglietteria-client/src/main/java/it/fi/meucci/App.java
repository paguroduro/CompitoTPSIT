package it.fi.meucci;
import java.io.IOException;
public final class App {
    private App() {
    }

    
    public static void main(String[] args) {
        SocketClient client = new SocketClient();
        client.connect();
        client.send();
    }
}
