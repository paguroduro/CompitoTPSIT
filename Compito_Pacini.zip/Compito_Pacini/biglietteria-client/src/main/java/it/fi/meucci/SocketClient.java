package it.fi.meucci;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.*;
import java.util.Scanner;

public class SocketClient {
    private Socket socket;
    private DataInputStream in;
    private DataOutputStream out;
    private Scanner keyboard = new Scanner(System.in);
    private String userString="";
    private String serverString;

    public Socket connect() throws IOException
    {
        this.socket = new Socket(InetAddress.getLocalHost(), 6789);
        this.in = new DataInputStream(socket.getInputStream());
        this.out = new DataOutputStream(socket.getOutputStream());
        return socket;
    }

    public void send() throws IOException
    {
        
        this.userString = this.keyboard.next();
        out.writeBytes(userString + '\n');
        serverString = in.readLine();
        ObjectMapper objectMapper = new ObjectMapper();
        Messaggio value = objectMapper.readValue(serverString);
        socket.close();
    }



    
}

